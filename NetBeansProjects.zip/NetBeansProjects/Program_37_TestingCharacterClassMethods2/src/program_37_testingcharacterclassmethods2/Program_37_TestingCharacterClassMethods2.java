/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: using Character. method to lower the chars.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_37_testingcharacterclassmethods2;


public class Program_37_TestingCharacterClassMethods2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String fullName="Kayla Shah";
        System.out.println(fullName);
        
        char firstInitial=fullName.charAt(0);
        System.out.println("First Initial: "+firstInitial);
        
        char lowerCaseInitial=Character.toLowerCase(firstInitial);
        System.out.println("Lower Case First Initial: "+lowerCaseInitial);
        
    }//end main method
    
}//end class

