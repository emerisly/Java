/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 * 
 */
package program_acsi_1_example2;

import java.util.Scanner;
/**
 *
 * @author Emerald Liu
 */
public class Program_ACSI_1_Example2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner console=new Scanner(System.in);
        String numbers=console.nextLine();
        String[] numbersArray=numbers.split("");
        
        
        
        
        
        
    }
    
}
