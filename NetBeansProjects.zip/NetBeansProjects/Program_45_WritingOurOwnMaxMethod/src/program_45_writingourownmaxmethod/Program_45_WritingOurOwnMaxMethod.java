/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: writing a max method and get the max of two numbers.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_45_writingourownmaxmethod;


public class Program_45_WritingOurOwnMaxMethod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The max is: "+max(5,7));
    }//end main method
    
    public static int max(int x,int y)
    {
        if (x>y)
            return x;
        return y;
    }
}//end class
