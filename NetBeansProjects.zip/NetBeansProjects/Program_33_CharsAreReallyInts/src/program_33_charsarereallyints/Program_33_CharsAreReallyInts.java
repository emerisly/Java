/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: shows how chars are stored as ints.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_33_charsarereallyints;


public class Program_33_CharsAreReallyInts {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        char letter='a'+2;
        System.out.println("Your letter is: "+letter);
        
        int code=65;
        char grade=(char)code;
        System.out.println("Your grade is: "+grade);
        
        for (char ch='a';ch<='z';ch++)
            System.out.print(ch+" ");
   
        
    }
    
}
