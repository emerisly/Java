/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: a bad program to recognize the input.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */


package program_15_badstringequalityprogram;

import java.util.Scanner;


public class Program_15_BadStringEqualityProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner userInput=new Scanner(System.in);
        
        System.out.println("yes or no?");
        String answer=userInput.next();
        
        if(answer=="yes")//this is a bad coding caz == is for comparing the reference but not value
            System.out.println("You answered \"yes\"");
        else if(answer=="no")//this is a bad coding caz == is for comparing the reference but not value
            System.out.println("You answered \"no\"");
        else
            System.out.println("I don't recognize your input");
        
        
    }//end main method
    
}//end class
