/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 * 
 */
package program_arrayexample;
import java.util.Scanner;

/**
 *
 * @author Emerald Liu
 */
public class Program_ArrayExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int []a=new int[5];
        
        int sum=0;
        int grade=0;
        int counter=0;
        
        Scanner console=new Scanner(System.in);
        
        //scan 5 grades
        while(counter<5)
        {
            System.out.println("what is your grade?");
            grade=console.nextInt();
            sum=sum+grade;
            counter++;
        }
        
        double avg=sum/counter;
        System.out.println("Avg is "+avg);
        
        
    }
    
}
