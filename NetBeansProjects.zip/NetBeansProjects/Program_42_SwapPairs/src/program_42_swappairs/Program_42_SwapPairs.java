/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: swap pairs for string and return the swapped string.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_42_swappairs;

import java.util.Scanner;

public class Program_42_SwapPairs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Please enter a word.");
        Scanner console=new Scanner(System.in);
        String word=console.nextLine();
        
        int length=word.length();
        
        
        //get theWord
        String theWord="";
        if (word.length()%2==0){
            theWord=word+theWord;
        }
        else{
            theWord=word.substring(0,length)+theWord;
        }
        
        //get the last character if length is odd
        String lastChar=word.substring(length-1,length);
        
        
        String even=theNewWordo(theWord);
        String odd=theNewWorde(theWord);
        
        String finishWord=finish(odd,even);
        
        if(word.length()%2!=0)
            finishWord=finishWord+lastChar;
            
        System.out.println("The swap pairs word is: "+finishWord);
                 
        
    }//end main method
    
    public static String theNewWordo(String a)
    {
            String odd="";
        
        for(int i=0;i<a.length();i+=2)
        {
            odd=odd+a.charAt(i);
        }
        return odd;
    }
    
        public static String theNewWorde(String a)
    {
            String even="";
        
        for(int i=1;i<a.length();i+=2)
        {
            even=even+a.charAt(i);
        }
        return even;
    }
    
        public static String finish(String o, String e)
        {
            String finishWord="";
            for (int i=0;i<o.length();i++)
                finishWord=finishWord+o.charAt(i)+e.charAt(i);
            return finishWord;
        }
    
    
}//end class
