/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: converting upper case and lower case for chars using Character. method.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_36_testingcharacterclassmethods;


public class Program_36_TestingCharacterClassMethods {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        char myChar='A';
        if(Character.isLowerCase(myChar))
            System.out.println("My char in lower case is: "+myChar);
        else
        {
            myChar=Character.toLowerCase(myChar);
            System.out.println("My char in lower case is: "+myChar);
        }
        
        
        
    }//end main method
    
}//end class
