/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: recognizing the input.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_16_goodstringequalityprogram;


import java.util.Scanner;


public class Program_16_GoodStringEqualityProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner userInput=new Scanner(System.in);
        System.out.println("yes or no?");
        String answer=userInput.next();
        if(answer.equals("yes"))
            System.out.println("you answered \"yes\"");
        else if(answer.equals("no"))
            System.out.println("you answered\"no\"");
        else
            System.out.println("I don't recognize your input");
      
    }//end main method
    
}//end class
