/**
 *
 * @author Emerald Liu
 * 
 * Description: See if the word starts with a vowel.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */


package program_08_ifelseifelseexample;


public class Program_08_ifElseIfElseExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String myString="excellent";
        
        if(myString.charAt(0)=='a')
            System.out.println("Your string starts with an a.");
        else if(myString.charAt(0)=='e')
            System.out.println("your string starts with an e.");
        else if(myString.charAt(0)=='i')
            System.out.println("your string starts with an i");
        else if(myString.charAt(0)=='0')
            System.out.println("your string starts with an o");
        else if(myString.charAt(0)=='u')
            System.out.println("your string starts with an u");
        else
            System.out.println("your string doesn't start with a vowel.");
    }//end main method
    
}//end class
