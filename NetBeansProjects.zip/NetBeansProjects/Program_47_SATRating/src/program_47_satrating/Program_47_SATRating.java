/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: See if the inputted SAT score is competitive.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_47_satrating;


public class Program_47_SATRating {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int score=2400;
        System.out.println("Your score is: "+rating(score));
 }//end main method
    
    public static String rating(int score)
    {
            if(score<600||score>2400)
                throw new IllegalArgumentException("score: "+score);
            else if (score>=600 && score<1200)
                return "not competitive";
            else if (score>=1200 && score<1800)
                return "competitive";
            else
                return "highly competitive";
            
    }
    
}//end class
