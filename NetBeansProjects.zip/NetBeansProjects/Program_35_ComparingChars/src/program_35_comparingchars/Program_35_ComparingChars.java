/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: compare char just like ints using ASCII. 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_35_comparingchars;


public class Program_35_ComparingChars {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        char c1='$';
        char c2='&';
        
        if(c1<c2)
            System.out.println(c1+" comes before "+c2);
        else
            System.out.println(c2+" comes befoer "+c1);
        
        
        
    }//end main method
    
}//end class
