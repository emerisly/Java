/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: see if have the same favorite color as Mrs. Shah.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_18_favoritecolor;

import java.util.Scanner;


public class Program_18_FavoriteColor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        
        
        System.out.println("Please enter your favouite color.");
        String color=console.next();
        
        
        if(color.toLowerCase().equals("blue"))
            System.out.println("You have the same favoutie color as Mrs. Shah.");
        else
            System.out.println("Your favorite color is the not the same as Mrs. Shah's.");
        
        
    }//end main method
    
}//end class
