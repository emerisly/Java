/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: errors when comparing doubles, and how to avoid this error using Math.abs.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_31_comparingdoubleexample;


public class Program_31_ComparingDoubleExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double cents3=0.01+0.05+0.10+0.25;
        double cents4=0.25+0.10+0.05+0.01;
        
        if(cents3==cents4)
            System.out.println("They are equal!");
        else
            System.out.println("They are not equal!");
        
        if(Math.abs(cents4-cents3)<0.0001)
            System.out.println("They are euqal!");
        else
            System.out.println("They are not equal!");
        
    }//end main method
    
}//end class
