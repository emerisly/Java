/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: get the max and min in a sequence of numbers.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_24_maxandminprogram;

import java.util.Scanner;

public class Program_24_MaxAndMinProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int min=Integer.MAX_VALUE;
        int max=Integer.MIN_VALUE;
        
        Scanner console=new Scanner(System.in);
        System.out.println("How many numbers do you have?");
        int number=console.nextInt();
        
        for(int i=1;i<=number;i++){
            System.out.print("    #"+i+"?  ");
            int next=console.nextInt();
            if(next<min)
                min=next;
            if(next>max)
                max=next;
        }
        
        System.out.println("Min: "+min);
        System.out.println("Max: "+max);
       
    }//end main method
    
}//end class
