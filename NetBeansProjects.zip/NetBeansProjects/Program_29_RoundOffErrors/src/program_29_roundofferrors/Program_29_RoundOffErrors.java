/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: a program shows the round off error.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_29_roundofferrors;


public class Program_29_RoundOffErrors {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int cents1=1+5+10+25;
        int cents2=25+10+5+1;
        System.out.println(cents1+" cents\n"+cents2+" cents");
        
        double cents3=0.01+0.05+0.10+0.25;
        double cents4=0.25+0.10+0.05+0.01;
        System.out.println(cents3+" cents"+"\n"+cents4+" cents");
    }//end main method
    
}//end class
