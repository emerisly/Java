/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: see how many even numbers are inputted.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_27_countevens;

import java.util.Scanner;


public class Program_27_CountEvens {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("How many numbers do you have?  ");
        Scanner console=new Scanner(System.in);
        int totalNumber=console.nextInt();
        
        int count=0;
        for(int i=1;i<=totalNumber;i++)
        {
            System.out.print("    #"+i+"?  ");
            int number=console.nextInt();
            if(number%2==0)
                count++;            
        }
        
        System.out.println("Number of evens: "+count);
        
        
        
    }//end main method
    
}//end class
