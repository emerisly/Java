/**
 *
 * @author Emerald Liu
 * 
 * Description: See what grade is the work.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */
package program_10_grades;

import java.util.Scanner;

public class Program_10_grades {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner console=new Scanner(System.in);
        int grade;
        System.out.println("Grade (0-100)?");
        grade=console.nextInt();
        
        //while loops ensures users enters proper grade
        while (grade>100||grade<0) {
            System.out.println("Grades must be from 0 to 100.");
            System.out.println("Grade (0-100)?");
            grade=console.nextInt();
        }
        
        
        if (grade<60)
            System.out.println("You got an F!");
        else if(grade<70)
            System.out.println("You got a D!");
        else if(grade<80)
            System.out.println("You got a C!");
        else if(grade<90)
            System.out.println("You got a B!");            
        else 
            System.out.println("You got an A!");
    }//end main method
    
}//end class
