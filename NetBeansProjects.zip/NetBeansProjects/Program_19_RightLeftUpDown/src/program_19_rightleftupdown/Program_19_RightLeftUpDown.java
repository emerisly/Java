/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: recognizing R,L,U,D from input.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_19_rightleftupdown;

import java.util.Scanner;


public class Program_19_RightLeftUpDown {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        System.out.println("Please enter R, L, U, or D");
        String letter=console.next();
        
        if(letter.equalsIgnoreCase("r"))
            System.out.println("You have chosen Right");
        else if(letter.equalsIgnoreCase("l"))
            System.out.println("You have chosen Left");
        else if(letter.equalsIgnoreCase("u"))
            System.out.println("You have chosen Up");
        else if(letter.equalsIgnoreCase("d"))
            System.out.println("You have chosen Down");
        else
            System.out.println("Unknown entry: "+letter);
    }//end main method
    
}//end class
