/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 * 
 */
package program_stringtointandwhileloop;
import java.util.Scanner;

/**
 *
 * @author Emerald Liu
 */
public class Program_StringToIntAndWhileLoop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int sum=0;
        int count=0;
        System.out.println("Please enter grade:");
        Scanner console=new Scanner(System.in);
        String gradeStr1=console.next();
        int grade=Integer.parseInt(gradeStr1);
        
        while(grade>=0){
            count++;
            sum=sum+grade;
            String gradeStr2=console.next();
            grade=Integer.parseInt(gradeStr2);
        }
        
        System.out.println("count: "+count+"\nsum: "+sum);
        
    }
    
}
