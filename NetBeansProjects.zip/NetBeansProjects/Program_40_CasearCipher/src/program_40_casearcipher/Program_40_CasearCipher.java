/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: do some casear cipher using chars since chars could be count in ints.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_40_casearcipher;

import java.util.Scanner;


public class Program_40_CasearCipher {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Please enter a word.");
        Scanner console=new Scanner(System.in);
        String word=console.nextLine();
        
        String newWord="";
        
        for(int i=0;i<word.length();i++)
        {
            if(word.charAt(i)=='x')
                newWord="a";
            else if(word.charAt(i)=='y')
                newWord="b";
            else if(word.charAt(i)=='z')
                newWord="c";
            else
                newWord=newWord+(char)(word.charAt(i)+3);            
        }
        
        System.out.println(newWord);
        
        
    }//end main method
    
}//end class
