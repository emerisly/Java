/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: testing multiple condition using &&.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_20_testingmultipleconditionsusingand;


public class Program_20_TestingMultipleConditionsUsingAnd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int number=5;
        
        if(number>=3){
            if(number<=10){
                //do something
            }
        }
        
        if(number>=3 && number<=10){
            //do something
        }
       
    }//end main method
    
}//end class
