/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: see if the input is a palindrome - a word that is the same with the backward characters.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_41_palindrome;

import java.util.Scanner;



public class Program_41_Palindrome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        System.out.print("Enter a string and I'll test to see if it is a palindrome: ");
        String myString=console.nextLine();
        String newString=reverse(myString);
        
        if(newString.equals(myString))
            System.out.println("Your text is a palindrome!");
        else
            System.out.println("You text is not a palindrome.");
        
    }//end main method
    
    public static String reverse(String phrase)
    {
        String nString="";
        for (int i=0;i<phrase.length();i++)
        {
            nString=phrase.charAt(i)+nString;
        }
        return nString;
    }//end reverse method
    
}//end class
