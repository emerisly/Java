/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 


         *abcde DONE

         *abce
         *abce
         *abde
         *acde
         *bcde

         *abc
         *abd
         *abe
         *acd
         *ace
         *ade
         *bcd
         *bce
         *bde
         *cde

         *ab
         *ac
         *ad
         *ae
         *bc
         *bd
         *be
         *cd
         *ce
         *de

         *a
         *b
         *c
         *d
         *e

         *_


 */
package program_acsi_1_example;

import java.util.Scanner;

/**
 *
 * @author Emerald Liu
 */
public class Program_ACSI_1_Example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        String nameString=console.nextLine();
        String[] nameArray=nameString.split(",");
        
        
//        for(String names:nameArray)
//            System.out.println(names);
        
//      for(int i=0;i<=nameArray.length-1;i++)
//          System.out.println(nameArray[i]);
        
        System.out.println("");
        
        int length1=nameArray.length;
        int length0=nameArray.length-1;
//        System.out.println(length);
        
        
        
        
        
            //total number:length
            System.out.print("{ ");
             for(int j=0;j<=length0;j++){
                 System.out.print(nameArray[j]+" ");
             }
             System.out.print(" }\n");
             
             
             //total number:length-1
             
             
             //total number:length-2
             
             
             
             //total number:length-length+1
             
             
             
             
             
             //total number:length-length
             System.out.print("{ ");
             System.out.print(" }\n");

        
        
        
        }
       
        
        
        
        
    }
