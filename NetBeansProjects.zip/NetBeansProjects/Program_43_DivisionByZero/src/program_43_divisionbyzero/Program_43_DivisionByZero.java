/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: show that numbers divided by zero is (-)infinity.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_43_divisionbyzero;

public class Program_43_DivisionByZero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double zeroDivision=1.0/0.0;
        System.out.println(zeroDivision);
        
        double multiply=-3*zeroDivision;
        System.out.println(multiply);
        
    }//end main method
}//end class
