/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: write a factorial method and count the factorial of a number.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_44_factorialexamplewithexceptions;


import java.util.Scanner;


public class Program_44_FactorialExampleWithExceptions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int number;
        Scanner console=new Scanner(System.in);
        
        System.out.println("What integer would you like to see the factorial of? Enter here: ");
        number = console.nextInt();
        System.out.println(number+"!: "+ factorial(number));
    }//end main method
        
        /*************************************************/
        //Pre-condition:  number >= 0
        //Post-condition:  returns n factorial (n!)
        
        public static int factorial(int n)
        {
            if(n<0)
                throw new IllegalArgumentException("Negative n: "+n);
            int product=1;
            for(int i=2; i<=n; i++)
                product=product*i;
            return product;
        }
    
}//end class
