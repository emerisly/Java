/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: making the string going backward, and also counting how many characters are there in the string.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_39_cumulativeconcatenationandcountletters;

import java.util.Scanner;


public class Program_39_CumulativeConcatenationAndCountLetters {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Enter a string:");
        Scanner console=new Scanner(System.in);
        String myString=console.nextLine();
        System.out.println("");
        
        String backwardPhrase=reverse(myString);
        System.out.println(backwardPhrase+"\n");
        int letterCount=countLetters(myString);
        System.out.println("There are "+letterCount+" letters in your phrase.");
        System.out.println("Not counting spaces and puncutaion.\n");

    }
    
    public static String reverse(String phrase)
    {
        String result="";
        for(int i=0;i<phrase.length();i++)
        {
            result=phrase.charAt(i)+result;
        }
        return result;
    }
    
    public static int countLetters(String phrase)
    {
        int count=0;
        for (int i=0;i<phrase.length();i++)
        {
            char ch=phrase.charAt(i);
            if(Character.isLetter(ch))
            {
                count++;
            }
        }
        return count;
    }//end main method
    
}//end class
