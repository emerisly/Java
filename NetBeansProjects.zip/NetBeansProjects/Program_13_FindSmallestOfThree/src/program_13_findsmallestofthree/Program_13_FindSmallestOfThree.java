/**
 *
 * @author Emerald Liu
 * 
 * Description: see which number is the smallest one.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_13_findsmallestofthree;

import java.util.Scanner;


public class Program_13_FindSmallestOfThree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        
        int a,b,c;
        System.out.println("Please enter value for a.");
        a=console.nextInt();
        System.out.println("Please enter value for b.");
        b=console.nextInt();
        System.out.println("Please enter value for c.");
        c=console.nextInt();
        
        if(a<=b & a<=c)
            System.out.println("a is the smallest.");
        else if(b<c)
            System.out.println("b is the smallest.");
        else
            System.out.println("c is the smallest.");
        
    }
    
}
