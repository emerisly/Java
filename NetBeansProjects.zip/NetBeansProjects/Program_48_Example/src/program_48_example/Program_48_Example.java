/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 * 
 */
package program_48_example;

/**
 *
 * @author Emerald Liu
 */
public class Program_48_Example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[] a={70,80,60,90,95,82,86,92,94,82};
        double sum=0;
        for(int i=0;i<a.length;i++)
            sum=sum+a[i];
        
        double avg=sum/a.length;
        System.out.println(avg);
    }
    
}
