/**
 *
 * @author Emerald Liu
 * 
 * Description: see which number is in the middle.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_11_nestedifstatements;


public class Program_11_NestedIfStatements {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int a=6;
        int b=4;
        int c=2;
        
        if (a<b && a<c) 
        {
            if (b<c) 
                System.out.println("B is the middle number!");
            else
                System.out.println("C is the middle number!");
        }
        
        else if(b<a && b<c)
        {
        if(a<c)
                System.out.println("A is the middle number!");
        else
                System.out.println("C is the middle number!");
        }
        
        else
        {
            if(b<a)
                System.out.println("B is the middle number!");
            else
                System.out.println("A is the middle number!");
        }
        
    }//end main method
    
}//end class
