/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: how to convert ints to chars using (char).
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_34_morefunwithchars;


public class Program_34_MoreFunWithChars {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        char myChar=120;
        System.out.println("My char is: "+myChar+"\n");
        
        for(int i=35; i<=130; i++)
            System.out.print((char)i+" ");
        
    }//end main method
    
}//end class
