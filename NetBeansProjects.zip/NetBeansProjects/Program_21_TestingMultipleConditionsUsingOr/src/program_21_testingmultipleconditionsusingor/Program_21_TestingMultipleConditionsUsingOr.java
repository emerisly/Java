/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: testing multiple condition using ||.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_21_testingmultipleconditionsusingor;


public class Program_21_TestingMultipleConditionsUsingOr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int number=3;
        
        if(number==1){
            //do something
        }
        if(number==2){
            //do the same thing
        }
        
        //using or operator
        if(number==1 || number==2){
        //do something
        }
    }//end main method
    
}//end class
