/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: recognizing input with a case insensitive program.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_17_writingacaseinsensitiveprogram;

import java.util.Scanner;

/**
 *
 * @author Emerald Liu
 */
public class Program_17_WritingACaseInsensitiveProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner keyboard=new Scanner(System.in);
        System.out.println("Enter yes or no:");
        String input=keyboard.next();
        
        if(input.toUpperCase().equals("YES"))
            System.out.println("You entered YES!");
        else if(input.toUpperCase().equals("NO"))
            System.out.println("YOu entered NO!");
        else
            System.out.println("You entered something werid.");
        
    }//end main method
    
}//end class
