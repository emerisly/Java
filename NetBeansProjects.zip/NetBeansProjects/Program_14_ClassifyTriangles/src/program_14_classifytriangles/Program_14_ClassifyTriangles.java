/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_14_classifytriangles;

import java.util.Scanner;


public class Program_14_ClassifyTriangles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner console=new Scanner(System.in);
        
        int a,b,c;
        System.out.println("Please enter value for the first side of the triangle.");
        a=console.nextInt();
        System.out.println("Please enter value for the second side of the triangle.");
        b=console.nextInt();
        System.out.println("Please enter value for the third side of the triangle.");
        c=console.nextInt();
        
        if(a==b&&b==c)
            System.out.println("equilateral");
        else if(a==b||b==c||a==c)
            System.out.println("isoceles");
        else
            System.out.println("scalene");
        
    }//end main method
    
}//end class
