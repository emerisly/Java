/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: examines a sequence of number to find the average and counts how many of them are negative.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_25_examinenumbers;

import java.util.Scanner;

public class Program_25_ExamineNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("This program examines a \nsequence of number to find \nthe average and counts how many \nof them are negative.\n");
        Scanner console=new Scanner(System.in);
        
        System.out.print("How many numbers do you have?  ");
        int totalNumber=console.nextInt();
        int negatives=0;
        double sum=0.0;
        
        for(int i=1;i<=totalNumber;i++)
        {
            System.out.print("    #"+i+"?  ");
            double next=console.nextDouble();
            sum+=next;
            if(next<0)
                negatives++;
        }
        System.out.println("");
    
    
        if(totalNumber<=0)
            System.out.println("No numbers to average!");
        else{
            double average=sum/totalNumber;
            System.out.println("Average= "+average);
        }
        System.out.println("Number of negatives= "+negatives);
    }//end main method
    
    
}//end class
