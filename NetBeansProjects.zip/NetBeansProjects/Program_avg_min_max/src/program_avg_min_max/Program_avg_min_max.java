/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 * 
 */
package program_avg_min_max;

import java.util.Scanner;


/**
 *
 * @author Emerald Liu
 */
public class Program_avg_min_max {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[] numbers={50,100,150};
        int sum=0;
        
        int min=Integer.MAX_VALUE;//set min to the biggest number
        int max=Integer.MIN_VALUE;//set max to the smallest number
        
        for(int i=0;i<=2;i++){
            sum=sum+numbers[i];
            if (numbers[i]<min)
                min=numbers[i];
            if (numbers[i]>max)
                max=numbers[i];
        }
        
        double avg=sum/3;
        
        System.out.println("Average is: "+avg+"\nMax is: "+max+"\nMin is: "+min);
        
        
            
        
        
        
        
        
        
    }
    
}
