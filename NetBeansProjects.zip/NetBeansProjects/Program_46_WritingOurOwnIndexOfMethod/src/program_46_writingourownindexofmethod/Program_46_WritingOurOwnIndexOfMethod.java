/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: see how many of some specific chars is in the String.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_46_writingourownindexofmethod;


public class Program_46_WritingOurOwnIndexOfMethod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String s="four score and seven years ago";
        int r=indexOf('r',s);
        int v=indexOf('z',s);
        System.out.println("Index of r: "+r);
        System.out.println("Index of z: "+v);

    }//end main method
    public static int indexOf(char ch, String s)
    {
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)==ch)
                return i;
        }
        return -1;
    }
}//end class
