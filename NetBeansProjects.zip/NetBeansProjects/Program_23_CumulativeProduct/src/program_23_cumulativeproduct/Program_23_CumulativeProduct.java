/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: multiply a sequence of numbers.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_23_cumulativeproduct;

import java.util.Scanner;


public class Program_23_CumulativeProduct {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      System.out.println("This program multiplies a senquence of numbers");
        System.out.println("");
        
        Scanner myScanner=new Scanner(System.in);
        
        System.out.println("How many numbers do you have?");
        int totalNumber=myScanner.nextInt();
        
        double product=1.0;
        for (int i=1; i<=totalNumber; i++)
        {
            System.out.print("    #"+i+"?  ");
            double next=myScanner.nextDouble();
            product*=next;//product=product*next
        }
        
        System.out.println("");
        System.out.println("Product="+product);
    }//end main method
        
}//end class
