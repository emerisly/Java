/**
 *
 * @author Emerald Liu
 * 
 * Description: Telling the vowels in the word.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */


package program_07_sequentialifs;

import java.util.Scanner;


public class Program_07_SequentialIfs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        System.out.println("Enter a word and I'll tell you all the");
        System.out.println("vowels in it.");
        
        String s=console.next();
        
        System.out.println("Your word contains the following vowels: ");
        //Note: the constains method takes a String and returns true of false
        
        if(s.contains("a"))
            System.out.println("a ");
        if(s.contains("e"))
            System.out.println("e ");
        if(s.contains("i"))
            System.out.println("i ");
        if(s.contains("o"))
            System.out.println("o ");
        if(s.contains("u"))
            System.out.println("u ");
        
        System.out.println("");
        System.out.println("Thank you for playing!");
        
    }//end main method
    
}//end class
