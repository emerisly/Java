/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: a program shows the round off errors.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_28_roundofferrors;


public class Program_28_RoundOffErrors {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double n=1.0;
        for(int i=1;i<=10;i++)
        {
            n=n+0.1;
            System.out.println(n);
        }
        
    }//end main method
    
}//end class
