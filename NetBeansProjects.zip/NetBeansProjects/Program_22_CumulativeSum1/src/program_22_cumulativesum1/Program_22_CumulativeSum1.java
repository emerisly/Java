/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: adding numbers together.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_22_cumulativesum1;

import java.util.Scanner;


public class Program_22_CumulativeSum1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("This program adds a senquence of numbers");
        System.out.println("");
        
        Scanner myScanner=new Scanner(System.in);
        
        System.out.println("How many numbers do you have?");
        int totalNumber=myScanner.nextInt();
        
        double sum=0.0;
        for (int i=1; i<=totalNumber; i++)
        {
            System.out.print("    #"+i+"?  ");
            double next=myScanner.nextDouble();
            sum+=next;//sum=sum+next
        }
        
        System.out.println("");
        System.out.println("Sum="+sum);
    }//end main method
    
}//end class
