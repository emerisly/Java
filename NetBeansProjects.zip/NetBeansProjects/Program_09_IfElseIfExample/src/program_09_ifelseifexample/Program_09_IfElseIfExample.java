/**
 *
 * @author Emerald Liu
 * 
 * Description: See if you can get a discount for movies.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_09_ifelseifexample;


public class Program_09_IfElseIfExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int yourAge=15;
        
        if (yourAge<=12) {
            System.out.println("You get the child discount.");
        } 
        else if(yourAge>=65){
            System.out.println("You get the senior discount.");
        }
        System.out.println("Thank you for coming to the movies");
    }//end main method
    
}//end class
