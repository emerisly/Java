/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: putting chars together to a string.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_32_printcharsinastring;

import java.util.Scanner;



public class Program_32_PrintCharsInAString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner console=new Scanner(System.in);
        System.out.println("Enter a string:");
        String myString=console.nextLine();
        
        System.out.println("");
        printVerticalChars(myString);//creat printVerticalChars Object!
        
    }
    
    public static void printVerticalChars (String message)
    {
        for (int i=0;i<message.length();i++)
        {
            char ch=message.charAt(i);
            System.out.println(ch);
        }
    }
}
