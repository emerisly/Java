/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: find how many is a specific char is in a String.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_38_findcharsinastring;


import java.util.Scanner;

public class Program_38_FindCharsInAString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        System.out.println("Enter a string to search. \nPress the enter key when you're done typing the string.");
        String myString=console.nextLine();
        
        System.out.println("\nEneter a character to find.\nPress the enter key whe you're done typing the character. ");
        String input=console.next();
        char ch=input.charAt(0);
        System.out.println();

        int count=countChar(myString,ch);
        
        System.out.println("There're "+count+" "+ch+"'s in the string.");
    
    }
    
    
    public static int countChar(String text, char c)
    {
        int found=0;
        for (int i=0; i<text.length(); i++)
        {
            if(text.charAt(i)==c)
            {
                found++;
            }
        }
        return found;
    }//end main method
    
}//end class
