/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: check how many factors are there.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_26_countfactors;

import java.util.Scanner;


public class Program_26_CountFactors {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console=new Scanner(System.in);
        
        System.out.println("Please enter an integer, and the program will check how many factors are there.");
        int number=console.nextInt();
        
        int count=0;
        for (int i=1;i<=number;i++)
        {
            if(number%i==0)
                count++;
        }
        
        System.out.println("Your number "+number+" has "+count+" factors.");
        
    }//end main method
    
}//end class
