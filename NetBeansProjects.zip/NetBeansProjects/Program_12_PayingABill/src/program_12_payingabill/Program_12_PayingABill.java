/**
 *
 * @author Emerald Liu
 * 
 * Description: see how do you need to pay the bill.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_12_payingabill;

import java.util.Scanner;

public class Program_12_PayingABill {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner console=new Scanner(System.in);
        System.out.println("Please enter your bill.");
        int billAcount=console.nextInt();
        
        if(billAcount<100)
            System.out.println("Please pay tht entire bill.");
        else if(billAcount<1000)
            System.out.println("Please pay the 1/2 of the bill.");
        else
            System.out.println("Please pay the 1/3 of the bill.");
        
    }
    
}
