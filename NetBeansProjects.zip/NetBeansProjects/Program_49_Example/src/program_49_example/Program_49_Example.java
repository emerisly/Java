/*
 * 
 * @author Emerald Liu
 * 
 * Description: 
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 * 
 */
package program_49_example;


import java.util.Scanner;

/**
 *
 * @author Emerald Liu
 */
public class Program_49_Example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner console=new Scanner(System.in);
        String names=console.next();
        String[] namesArray=names.split(",");
        System.out.println(namesArray);
        
        
    }
    
}
