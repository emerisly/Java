/**
 *
 * @author Emerald Liu
 * 
 * 
 * Description: using big decimal class to avoid round off errors.
 * 
 * I certify that this program is my own work and was not copied and/or modified from another student, website, or source.
 * 
 */

package program_30_bigdecimalclassexample;

import java.math.BigDecimal;

public class Program_30_BigDecimalClassExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        BigDecimal cents1=new BigDecimal("0.01");
        BigDecimal cents2=new BigDecimal("0.05");
        BigDecimal cents3=new BigDecimal("0.10");
        BigDecimal cents4=new BigDecimal("0.25");
        
        BigDecimal total=new BigDecimal("0.0");
        total=total.add(cents1);
        total=total.add(cents2);
        total=total.add(cents3);
        total=total.add(cents4);
        
        System.out.println("Sum: "+total);
        
        
        
    }//end main method
    
}//end class
